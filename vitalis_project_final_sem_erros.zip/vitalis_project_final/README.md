# Vitalis - Painel Financeiro

Site HTML estático para GitHub Pages.

## Senha de acesso

`vitalis2026`

## Ficheiros necessários

- `index.html`
- `dados-financeiros.json`
- `vitalis-logo.png`

## Como atualizar dados

Edite o ficheiro `dados-financeiros.json`, faça commit e aguarde o GitHub Pages atualizar.
